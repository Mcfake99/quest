# QuestForge

GCSE revision game: a 30-minute daily revision run, Leitner flashcards, and timed past-paper sittings (Business and Maths Higher).

History practice is WW1, WW2, Elizabeth I, and the Vietnam War.

## Run

```bash
npm install
npm run dev
```

The dev server is set up for port 8080. Sign-in and cloud save need the platform database and auth environment; progress also stays in the browser.
